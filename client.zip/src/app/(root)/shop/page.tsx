import React from "react";
import ShopPage from "./ShopPage";
export const metadata={
  title:"Shop"
}
const Shop = () => {
  return <ShopPage />;
};

export default Shop;
