// import { RootContext } from "@/context/root.context";
// import { useContext } from "react";

// const useRootContext = () => {
//   return useContext(RootContext);
// };

// export { useRootContext };
