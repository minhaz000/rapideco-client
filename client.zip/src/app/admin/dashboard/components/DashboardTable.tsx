import React from "react";
import Order from "../../(order)/all-order/page";
const DashboardTable = () => {
  return <Order />;
};

export default DashboardTable;
