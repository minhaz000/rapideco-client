interface IForget {
  email: string;
}

export default IForget;
