interface IUser {
  username: string;
  password: string;
}

export default IUser;
